To view this file, you must have NetStumbler installed on your computer.
http://netstumbler.com


This is the scan I performed while riding the bus one afternoon after school.  
This scan was performed using an Orinoco 802.11b card with an external antenna.  No GPS device was used in locating the access points.

Quick stats:

80 total spots
79 APs
1 Peer
48 unprotected spots
32 WEP protected spots
16 default SSIDs



1 of the linksys hotspots were easily cracked into by Face and I.  As you can see, more than 50% of the hotspots were left unprotected and 20% left the SSIDs the same, meaning the passwords on the router are probably left unchanged also.


This scan was made by willjasen.
http://willjasen.vze.com
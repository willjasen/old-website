http://willjasen.be

Coded by willjasen


Game Play:

The goal of the game is to remove all cards from your hand.

To do this, you must lay down 1 card, 2, 3, 4 of the same card.  The next player then must lay an equal or higher card, but they must have the exact number that the round was begun with.

For example:  You start the round with 2 5's.  Double 5's are on the table.  The next player must lay doubles also, but they must be 5 or higher.


General Instructions:


All letters input must be uppercase. (I'll fix later.)
To pass, type an uppercase P.

Round represents the whatever is being played (singles, etc.)
Round ends when each player passes.

Game over when someone no longer has cards.

To currently play the game without the screen going away at the end of the game, open up a command prompt, navigate to the folder where the game is stored, and type in the filename of the game (whatever you named it; it's pres by default).
